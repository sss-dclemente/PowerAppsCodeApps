# Power Core SDK

This project contains the APIs needed to initialize the player and add connections to your app.
