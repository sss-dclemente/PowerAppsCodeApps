/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePluginAsync } from './PluginCommon';
import { loadConnections } from './ConnectionUtils';
import { IOperationResult } from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataRuntime.Types';

let loadConnectionsPromise: Promise<void> | undefined;

/**
 * Executes operations using the plugin.
 */
export class OperationExecutor {
  /**
   * Executes an operation using the plugin.
   * @param operationName The name of the operation.
   * @param action The action to perform.
   * @param params The parameters for the operation.
   * @returns A promise resolving to the operation result.
   */
  public async execute<T = string>(
    operationName: string,
    action: string,
    params: unknown[]
  ): Promise<IOperationResult<T>> {
    try {
      if (!loadConnectionsPromise) {
        loadConnectionsPromise = loadConnections();
      }

      await loadConnectionsPromise;

      const result = await executePluginAsync<T>(operationName, action, params);
      return {
        success: true,
        data: result,
      };
    } catch (error) {
      return {
        success: false,
        data: undefined as T,
        error: error instanceof Error ? error : new Error('Unknown error occurred'),
      };
    }
  }
}
