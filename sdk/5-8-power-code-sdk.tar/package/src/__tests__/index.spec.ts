/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { describe, expect, it } from '@jest/globals';

describe('Power Core SDK', () => {
  it('is successful', () => {
    expect(1).toBe(1);
  });
});

export {};
