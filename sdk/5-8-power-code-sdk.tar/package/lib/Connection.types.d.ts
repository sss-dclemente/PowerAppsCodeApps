/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type Connection = {
    apiId: string;
    connectionName: string;
    runtimeUrl: string;
    isShareableConnection: boolean;
};
export type Connections = Record<string, Connection>;
//# sourceMappingURL=Connection.types.d.ts.map