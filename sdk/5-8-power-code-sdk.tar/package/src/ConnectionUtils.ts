/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { Connections } from './Connection.types';
import { executePluginAsync } from './PluginCommon';

let connectionsLoaded = false;

export async function loadConnections(): Promise<void> {
  if (connectionsLoaded) {
    return;
  }

  connectionsLoaded = true;
  await loadNonCompositeConnectionsAsync();
  await resolveCompositeConnectionsAsync();
}

async function loadNonCompositeConnectionsAsync(): Promise<Connections> {
  return executePluginAsync('AppPowerAppsClientPlugin', 'loadNonCompositeConnectionsAsync', []);
}

async function resolveCompositeConnectionsAsync(): Promise<Connections> {
  return executePluginAsync('AppPowerAppsClientPlugin', 'resolveCompositeConnectionsAsync', []);
}
