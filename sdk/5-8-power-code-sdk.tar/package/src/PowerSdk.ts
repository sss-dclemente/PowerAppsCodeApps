/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import PowerDataSourcesInfoProvider from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataSourcesInfoProvider';
import {
  DataSourcesInfo,
  IPowerDataRuntime,
} from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataRuntime.Types';
import { getPowerDataRuntime } from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataRuntimeInstance';
import { OperationExecutor } from './OperationExecutor';

/**
 * PowerSdk provides functions for accessing PowerDataRuntime.
 */

let instance: IPowerDataRuntime | undefined;

/**
 * Retrieves the singleton instance of the Power Runtime.
 * Initializes the instance if it doesn't already exist.
 * @returns The singleton instance of IPowerDataRuntime.
 */
export function getPowerSdkInstance(dataSourcesInfo: DataSourcesInfo): IPowerDataRuntime {
  if (!instance) {
    instance = getPowerDataRuntime(
      PowerDataSourcesInfoProvider.getInstance(dataSourcesInfo),
      new OperationExecutor()
    );
  }

  return instance;
}
