/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

export type HostMessage = {
  isPluginCall: boolean;
  callbackId: string;
  status: number;
  args: unknown[];
  keepCallback: boolean;
  messageType: 'initCommunication';
  antiCSRFToken: string;
};

let antiCSRFToken: string | undefined;
let currentCallbackId = 0;
const callbacks: Record<string, { resolve: (args: unknown) => void; reject: (reason: unknown) => void }> = {};
let postMessageSource: MessagePort | undefined;
const instanceId = Date.now().toString();
const messageChannel = new window.MessageChannel();
const postMessageQueue: Array<{ antiCSRFToken?: string }> = [];

export async function initializePlugins(): Promise<void> {
  initializeMessageChannel();
  (window as unknown as { executePluginAsync: unknown }).executePluginAsync = executePluginAsync;
}

export function executePluginAsync<T = unknown>(
  pluginName: string,
  pluginAction: string,
  params: unknown[] = []
): Promise<T> {
  return new Promise<unknown>((resolve, reject) => {
    const callbackId = getCallbackId(pluginName);
    callbacks[callbackId] = { resolve, reject };
    sendMessage({
      isPluginCall: true,
      callbackId,
      service: pluginName,
      action: pluginAction,
      actionArgs: params,
      antiCSRFToken,
    });
  }) as Promise<T>;
}

export function executePlugin(pluginName: string, pluginAction: string, params: unknown[] = []): void {
  sendMessage({
    isPluginCall: true,
    callbackId: getCallbackId(pluginName),
    service: pluginName,
    action: pluginAction,
    actionArgs: params,
    antiCSRFToken,
  });
}

function initializeMessageChannel(): void {
  messageChannel.port1.onmessage = handleMessage;
  // eslint-disable-next-line @microsoft/sdl/no-postmessage-star-origin
  window.parent.postMessage(
    {
      messageType: 'initCommunicationWithPort',
      instanceId,
    },
    '*',
    [messageChannel.port2]
  );
}

function getCallbackId(pluginName: string): string {
  return 'instanceId=' + instanceId + '_' + pluginName + currentCallbackId++;
}

function sendMessage(message: object): void {
  if (!postMessageSource) {
    postMessageQueue.push(message);
  } else {
    postMessageSource.postMessage(message);
  }
}

function handleMessage(messageEvent: MessageEvent<unknown>): void {
  const message = messageEvent.data as HostMessage;

  // Capture only the messages that are sent via the App Host's CommunicationChannel
  // which always provides an isPluginCall boolean value.
  if (message && typeof message.isPluginCall === 'boolean') {
    // message can be either a native plugin call result, or a script to execute
    if (message.isPluginCall) {
      // this is the result of a plugin call, extract the parameters and return them
      const callbackId = message.callbackId;
      const status = message.status;
      const args = message.args;
      const keepCallback = message.keepCallback;
      try {
        const callback = callbacks[callbackId];
        if (callback) {
          if (status === 1) {
            callback.resolve(args[0]);
          } else if (status !== 0) {
            callback.reject(args);
          }
          if (!keepCallback) {
            delete callbacks[callbackId];
          }
        }
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error(error);
      }
    }
  } else if (message && message.messageType === 'initCommunication') {
    antiCSRFToken = message.antiCSRFToken;
    postMessageSource = messageChannel.port1;
    (window as unknown as { PluginMessageSource: MessagePort }).PluginMessageSource = postMessageSource;

    if (postMessageSource) {
      for (let i = 0; i < postMessageQueue.length; i++) {
        // backfill csrf token
        postMessageQueue[i].antiCSRFToken = antiCSRFToken;
        postMessageSource.postMessage(postMessageQueue[i]);
      }
    }
  }
}
