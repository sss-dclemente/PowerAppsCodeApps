/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function loadConnections(): Promise<void>;
//# sourceMappingURL=ConnectionUtils.d.ts.map