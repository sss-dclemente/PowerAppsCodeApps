/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePlugin, initializePlugins } from './PluginCommon';
import { initializeMobilePlugin, isMobilePlayer } from './PluginMobile';

let initialized = false;

export async function initialize(): Promise<void> {
  if (initialized) {
    return;
  }
  initialized = true;

  if (isMobilePlayer()) {
    initializeMobilePlugin();
    return;
  }

  await initializePlugins();

  executePlugin('AppLifecycle', 'notifyAppIndexLoaded');
  executePlugin('AppLifecycle', 'notifyAppLoaded', ['', {}]);
}
