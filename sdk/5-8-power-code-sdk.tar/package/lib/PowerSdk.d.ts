/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { DataSourcesInfo, IPowerDataRuntime } from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataRuntime.Types';
/**
 * Retrieves the singleton instance of the Power Runtime.
 * Initializes the instance if it doesn't already exist.
 * @returns The singleton instance of IPowerDataRuntime.
 */
export declare function getPowerSdkInstance(dataSourcesInfo: DataSourcesInfo): IPowerDataRuntime;
//# sourceMappingURL=PowerSdk.d.ts.map