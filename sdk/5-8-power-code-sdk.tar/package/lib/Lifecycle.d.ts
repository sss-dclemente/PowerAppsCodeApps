/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function initialize(): Promise<void>;
//# sourceMappingURL=Lifecycle.d.ts.map