/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePluginAsync } from './PluginCommon';

export async function exchangeAllPluginVersions(): Promise<void> {
  await executePluginAsync('VersionSupport', 'exchangeAllPluginVersions', [
    {
      pluginVersionArray: [
        {
          serviceName: 'AppHostPlugin',
          actionName: 'getHidePlayerErrorToastsFeatureEnabledAsync',
          version: '1',
        },
        { serviceName: 'AppHostPlugin', actionName: 'refreshConnectionsAsync', version: '1' },
        { serviceName: 'AppHostPlugin', actionName: 'handleAppRuntimeErrorAsync', version: '1' },
        { serviceName: 'SienaFilePickerPlugin', actionName: 'launchSelectFilePickerV2', version: '1' },
        {
          serviceName: 'AppPowerAppsClientPlugin',
          actionName: 'getAppCdsDataSourceConfigsAsync',
          version: '1',
        },
        {
          serviceName: 'AppPowerAppsClientPlugin',
          actionName: 'getAppCdsDatabaseReferenceComponents',
          version: '1',
        },
        { serviceName: 'AppPowerAppsClientPlugin', actionName: 'getPcfUserIdFromCdsAsync', version: '1' },
        { serviceName: 'AppPowerAppsClientPlugin', actionName: 'backgroundFlowInstall', version: '1' },
        { serviceName: 'AppPowerAppsClientPlugin', actionName: 'getAppMetadataAsync', version: '1' },
        { serviceName: 'AppPowerAppsClientPlugin', actionName: 'getHostMetadataAsync', version: '1' },
        {
          serviceName: 'AppPowerAppsClientPlugin',
          actionName: '@LocalPlugin.versionsCSV',
          version: '1.0,2.0',
        },
        { serviceName: 'PowerAppsServicePlugin', actionName: 'getPowerAppsCurrentUserV2', version: '1' },
        { serviceName: 'PowerAppsServicePlugin', actionName: '@LocalPlugin.versionsCSV', version: '2.0' },
        {
          serviceName: 'ErrorSerializersManager',
          actionName: '@LocalSerializer.typesSetVersion',
          version: '0',
        },
        { serviceName: 'AppIdentityServicePlugin', actionName: '@LocalPlugin.versionsCSV', version: '2.0' },
        { serviceName: 'SaveDataLoadDataPlugin', actionName: '@LocalPlugin.versionsCSV', version: '1.0' },
      ],
    },
  ]);
}
