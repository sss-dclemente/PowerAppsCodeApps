/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type HostMessage = {
    isPluginCall: boolean;
    callbackId: string;
    status: number;
    args: unknown[];
    keepCallback: boolean;
    messageType: 'initCommunication';
    antiCSRFToken: string;
};
export declare function initializePlugins(): Promise<void>;
export declare function executePluginAsync<T = unknown>(pluginName: string, pluginAction: string, params?: unknown[]): Promise<T>;
export declare function executePlugin(pluginName: string, pluginAction: string, params?: unknown[]): void;
//# sourceMappingURL=PluginCommon.d.ts.map