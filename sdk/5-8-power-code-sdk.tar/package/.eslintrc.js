/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

module.exports = {
  extends: ['./node_modules/@pa-client/build-scripts/.eslintrc.base.js'],
  rules: {
    'no-external-vars': [
      'error',
      {
        allowedList: [
          'Blob',
          'console*',
          'MessageEvent',
          'MessagePort',
          'window*',
          'cordova*',
          'URLSearchParams',
          'document*',
          'HTMLScriptElement',
          'Event',
          'ErrorEvent',
        ],
      },
    ],
  },
};
