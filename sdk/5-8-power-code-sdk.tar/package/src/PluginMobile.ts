/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  // eslint-disable-next-line @typescript-eslint/prefer-namespace-keyword, @typescript-eslint/no-namespace
  module cordova {
    export function exec(
      success: (data: any) => any,
      fail: (err: any) => any,
      service: string,
      action: string,
      args?: any[]
    ): void;
  }
}

export function initializeMobilePlugin() {
  setupCordovaListener();
  loadCordova();
}

export function isMobilePlayer() {
  const searchParams = new URLSearchParams(window.location.search);
  return searchParams.get('loaderType') === 'reactnative';
}

function loadCordova() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      callLoader();
    });
  } else {
    callLoader();
  }
}

function setupCordovaListener() {
  document.addEventListener('deviceready', () => {
    notifyAppLoaded();
  });
}

function notifyAppLoaded() {
  if (typeof cordova !== 'undefined') {
    cordova.exec(
      // eslint-disable-next-line no-empty-function
      () => {},
      // eslint-disable-next-line no-empty-function
      () => {},
      'AppLifecycle',
      'notifyAppLoaded',
      []
    );
  }
}

function callLoader() {
  const searchString = window.location.search.substring(1);
  const params = searchString.split('&');
  let appServerUrl = '';
  let loaderPath = '';
  params.forEach((param) => {
    const pair = param.split('=');
    if (pair.length === 2) {
      const key = decodeURIComponent(pair[0]);
      const value = decodeURIComponent(pair[1]);
      if (key === 'loader') {
        loaderPath = value.substring(1);
      } else if (key === 'appServerUrl') {
        appServerUrl = value;
      }
    }
  });
  if (appServerUrl !== '' && loaderPath !== '') {
    addScript(`${appServerUrl}${loaderPath}`);
  }
}

function addScript(
  src: string,
  successCallback?: (event: Event) => void,
  failCallback?: (event: ErrorEvent) => void
) {
  const scriptTag = document.createElement('SCRIPT') as HTMLScriptElement;
  scriptTag.setAttribute('crossorigin', 'anonymous');
  scriptTag.type = 'text/javascript';
  scriptTag.async = false;
  if (successCallback) {
    scriptTag.addEventListener('load', successCallback);
  }
  if (failCallback) {
    scriptTag.addEventListener('error', failCallback);
  }
  document.head.appendChild(scriptTag);
  scriptTag.src = src;
}
