/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
declare global {
    namespace cordova {
        function exec(success: (data: any) => any, fail: (err: any) => any, service: string, action: string, args?: any[]): void;
    }
}
export declare function initializeMobilePlugin(): void;
export declare function isMobilePlayer(): boolean;
//# sourceMappingURL=PluginMobile.d.ts.map