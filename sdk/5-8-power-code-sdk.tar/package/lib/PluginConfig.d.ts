/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function exchangeAllPluginVersions(): Promise<void>;
//# sourceMappingURL=PluginConfig.d.ts.map